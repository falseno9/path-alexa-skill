# path-alexa-skill
Alexa skill to find out next train on PATH service from your location to a particular destination
